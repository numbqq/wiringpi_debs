/*------------------------------------------------------------------------------------------*/
/*																							*/
/*					WiringPi KHADAS_VIM_5 Board Headler file									*/
/*																							*/
/*------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------*/
#ifndef __KHADAS_VIM_5_H__
#define __KHADAS_VIM_5_H__

/*------------------------------------------------------------------------------------------*/
#define VIM_5_GPIO_MASK					(0xFFFFFF00)
#define VIM_5_GPIO_BASE					0xfe004000
#define VIM_5_GPIOAO_BASE				0xffa04000
#define VIM_5_GPIO_PWM_BASE			0xfe058000

#define VIM_5_GPIO_PIN_BASE				512

#define VIM_5_GPIOZ_PIN_START			512
#define VIM_5_GPIOZ_PIN_END			527
#define VIM_5_GPIOX_PIN_START			528
#define VIM_5_GPIOX_PIN_END			545
#define VIM_5_GPIOH_PIN_START			546
#define VIM_5_GPIOH_PIN_END			553
#define VIM_5_GPIOM_PIN_START			554
#define VIM_5_GPIOM_PIN_END			561
#define VIM_5_GPIOB_PIN_START			562
#define VIM_5_GPIOB_PIN_END			575
#define VIM_5_GPIOA_PIN_START			576
#define VIM_5_GPIOA_PIN_END			595
#define VIM_5_GPIOY_PIN_START			596
#define VIM_5_GPIOY_PIN_END			605
#define VIM_5_GPIOCC_PIN_START			606
#define VIM_5_GPIOCC_PIN_END			607

/* A9 GPIOD/GPIOAO/GPIOC live in gpiomem-ao. */
#define VIM_5_GPIOAO_PIN_START			608
#define VIM_5_GPIOAO_PIN_END			620
#define VIM_5_GPIOC_PIN_START			621
#define VIM_5_GPIOC_PIN_END			627
#define VIM_5_GPIOD_PIN_START			628
#define VIM_5_GPIOD_PIN_END			645

#define VIM_5_GPIOA_INP_REG_OFFSET		0x0A0
#define VIM_5_GPIOA_OUTP_REG_OFFSET		0x0A1
#define VIM_5_GPIOA_FSEL_REG_OFFSET		0x0A2
#define VIM_5_GPIOA_PUEN_REG_OFFSET		0x0A3
#define VIM_5_GPIOA_PUPD_REG_OFFSET		0x0A4
#define VIM_5_GPIOA_DS_REG_OFFSET		0x0A7
#define VIM_5_GPIOA_MUX_REG_OFFSET		0x010

#define VIM_5_GPIOM_INP_REG_OFFSET		0x068
#define VIM_5_GPIOM_OUTP_REG_OFFSET		0x069
#define VIM_5_GPIOM_FSEL_REG_OFFSET		0x06A
#define VIM_5_GPIOM_PUEN_REG_OFFSET		0x06B
#define VIM_5_GPIOM_PUPD_REG_OFFSET		0x06C
#define VIM_5_GPIOM_DS_REG_OFFSET		0x06F
#define VIM_5_GPIOM_MUX_REG_OFFSET		0x008

#define VIM_5_GPIOY_INP_REG_OFFSET		0x0B0
#define VIM_5_GPIOY_OUTP_REG_OFFSET		0x0B1
#define VIM_5_GPIOY_FSEL_REG_OFFSET		0x0B2
#define VIM_5_GPIOY_PUEN_REG_OFFSET		0x0B3
#define VIM_5_GPIOY_PUPD_REG_OFFSET		0x0B4
#define VIM_5_GPIOY_DS_REG_OFFSET		0x0B7
#define VIM_5_GPIOY_MUX_0_REG_OFFSET	0x00C
#define VIM_5_GPIOY_MUX_1_REG_OFFSET	0x00D

#define VIM_5_GPIOD_INP_REG_OFFSET		0x017
#define VIM_5_GPIOD_OUTP_REG_OFFSET		0x018
#define VIM_5_GPIOD_FSEL_REG_OFFSET		0x019
#define VIM_5_GPIOD_PUEN_REG_OFFSET		0x01A
#define VIM_5_GPIOD_PUPD_REG_OFFSET		0x01B
#define VIM_5_GPIOD_DS_REG_OFFSET		0x01E
#define VIM_5_GPIOD_MUX_REG_OFFSET		0x002
#define VIM_5_GPIOD_MUX_D17_REG_OFFSET	0x001

#define VIM_5_PWM_J_OFFSET				0x100
#define VIM_5_PWM_0_DUTY_CYCLE_OFFSET	(VIM_5_PWM_J_OFFSET + 0x00)
#define VIM_5_PWM_1_DUTY_CYCLE_OFFSET	(VIM_5_PWM_J_OFFSET + 0x01)
#define VIM_5_PWM_MISC_REG_01_OFFSET	(VIM_5_PWM_J_OFFSET + 0x02)

/// PWM_MISC_REG_CD
#define VIM_5_PWM_1_INV_EN         ( 27 )
#define VIM_5_PWM_0_INV_EN         ( 26 )
#define VIM_5_PWM_1_CLK_EN         ( 23 )
#define VIM_5_PWM_1_CLK_DIV0       ( 16 )  /// 22 ~ 16
#define VIM_5_PWM_0_CLK_EN         ( 15 )
#define VIM_5_PWM_0_CLK_DIV0       ( 8 )   /// 14 ~ 8
#define VIM_5_PWM_1_CLK_SEL0       ( 6 )   /// 7 ~ 6
#define VIM_5_PWM_0_CLK_SEL0       ( 4 )   /// 5 ~ 4
#define VIM_5_PWM_1_DS_EN          ( 3 )
#define VIM_5_PWM_0_DS_EN          ( 2 )
#define VIM_5_PWM_1_EN         ( 1 )
#define VIM_5_PWM_0_EN         ( 0 )

#ifdef __cplusplus
extern "C"{
#endif

extern void init_khadas_vim_5(struct libkhadas *libwiring);

#ifdef __cplusplus
}
#endif

#endif /* __KHADAS_VIM_5_H__ */
